Bower package for latest SB Admin 2 Bootstrap template

http://startbootstrap.com/template-overviews/sb-admin-2/
